export interface T {
	[key: string]: any;
}


