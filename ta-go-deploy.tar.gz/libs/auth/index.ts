import decodeJWT from 'jwt-decode';
import { initializeApollo } from '../../apollo/client';
import { userVar } from '../../apollo/store';
import { CustomJwtPayload } from '../types/customJwtPayload';
import { sweetMixinErrorAlert } from '../types/sweetAlert';
import { LOGIN, SIGN_UP } from '../../apollo/user/mutation';
import { AuthProvider, MemberRole, MemberType } from '../enums/member.enum';
import { safeLogout } from '../utils/security';

// Export AuthProvider for use in components
export { AuthProvider, MemberRole, MemberType };
// Backward compatibility alias
export { AuthProvider as MemberAuthType };

// 인증 관련 상수들
export const AUTH_CONSTANTS = {
	DEFAULT_AUTH_TYPE: AuthProvider.EMAIL,
	TOKEN_KEY: 'accessToken',
	LOGIN_TIME_KEY: 'login',
	LOGOUT_TIME_KEY: 'logout',
	DEFAULT_PROFILE_IMAGE: '/img/profile/defaultUser.svg',
} as const;

export function getJwtToken(): any {
	if (typeof window !== 'undefined') {
		return localStorage.getItem(AUTH_CONSTANTS.TOKEN_KEY) ?? '';
	}
}

export function setJwtToken(token: string) {
	localStorage.setItem(AUTH_CONSTANTS.TOKEN_KEY, token);
}

export const logIn = async (nick: string, password: string): Promise<void> => {
	try {
		const { jwtToken } = await requestJwtToken({ nick, password });

		if (jwtToken) {
			updateStorage({ jwtToken });
			updateUserInfo(jwtToken);
		}
	} catch (err) {
		console.warn('login err', err);
		logOut();
		throw new Error('Login Err');
	}
};

const requestJwtToken = async ({
	nick,
	password,
}: {
	nick: string;
	password: string;
}): Promise<{ jwtToken: string }> => {
	const apolloClient = await initializeApollo();

	try {
		const result = await apolloClient.mutate({
			mutation: LOGIN,
			variables: { input: { memberNick: nick, memberPassword: password } },
			fetchPolicy: 'network-only',
		});

		console.log('---------- login ----------');
		const { accessToken } = result?.data?.login;

		return { jwtToken: accessToken };
	} catch (err: any) {
		console.log('request token err', err.graphQLErrors);
		switch (err.graphQLErrors[0].message) {
			case 'Definer: login and password do not match':
				await sweetMixinErrorAlert('Please check your password again');
				break;
			case 'Definer: user has been blocked!':
				await sweetMixinErrorAlert('User has been blocked!');
				break;
		}
		throw new Error('token error');
	}
};

export const signUp = async (nick: string, password: string, contactInfo: string, authType: AuthProvider, memberType: MemberType = MemberType.USER): Promise<void> => {
	try {
		const { jwtToken } = await requestSignUpJwtToken({ nick, password, contactInfo, authType, memberType });

		if (jwtToken) {
			updateStorage({ jwtToken });
			updateUserInfo(jwtToken);
		}
	} catch (err) {
		console.warn('signup err', err);
		logOut();
		throw new Error('Signup Err');
	}
};

const requestSignUpJwtToken = async ({
	nick,
	password,
	contactInfo,
	authType,
	memberType,
}: {
	nick: string;
	password: string;
	contactInfo: string;
	authType: AuthProvider;
	memberType: MemberType;
}): Promise<{ jwtToken: string }> => {
	const apolloClient = await initializeApollo();

	try {
		// 인증 타입에 따라 적절한 필드 설정
		const input: any = {
			memberNick: nick,
			memberPassword: password,
			memberType: memberType,
			memberAuthType: authType
		};

		if (authType === AuthProvider.EMAIL) {
			input.memberEmail = contactInfo;
		} else if (authType === AuthProvider.PHONE) {
			input.memberPhone = contactInfo;
		}

		console.log('Sending signup mutation with variables:', input);
		
		const result = await apolloClient.mutate({
			mutation: SIGN_UP,
			variables: { input },
			fetchPolicy: 'network-only',
		});

		console.log('---------- signup result ----------');
		console.log('Full result:', result);
		console.log('Data:', result?.data);
		console.log('Signup data:', result?.data?.signup);
		
		const { accessToken } = result?.data?.signup;
		console.log('Access token:', accessToken);

		return { jwtToken: accessToken };
	} catch (err: any) {
		console.log('request signup token err', err);
		
		// GraphQL 에러가 있는 경우
		if (err.graphQLErrors && err.graphQLErrors.length > 0) {
			const errorMessage = err.graphQLErrors[0].message;
			console.log('GraphQL error message:', errorMessage);
			
			switch (errorMessage) {
				case 'Definer: login and password do not match':
					await sweetMixinErrorAlert('Please check your password again');
					break;
				case 'Definer: user has been blocked!':
					await sweetMixinErrorAlert('User has been blocked!');
					break;
				case 'Definer: user already exists':
					await sweetMixinErrorAlert('이미 존재하는 사용자입니다.');
					break;
				case 'Definer: invalid email format':
					await sweetMixinErrorAlert('올바른 이메일 형식을 입력해주세요.');
					break;
				case 'Definer: invalid phone format':
					await sweetMixinErrorAlert('올바른 전화번호 형식을 입력해주세요.');
					break;
				default:
					await sweetMixinErrorAlert(errorMessage || '회원가입 중 오류가 발생했습니다.');
					break;
			}
		} else if (err.networkError) {
			// 네트워크 에러인 경우
			console.log('Network error:', err.networkError);
			await sweetMixinErrorAlert('네트워크 연결을 확인해주세요.');
		} else {
			// 기타 에러
			console.log('Other error:', err);
			await sweetMixinErrorAlert('회원가입 중 오류가 발생했습니다.');
		}
		
		throw new Error('signup token error');
	}
};

export const updateStorage = ({ jwtToken }: { jwtToken: any }) => {
	setJwtToken(jwtToken);
	window.localStorage.setItem(AUTH_CONSTANTS.LOGIN_TIME_KEY, Date.now().toString());
};

export const updateUserInfo = (jwtToken: any) => {
	if (!jwtToken) return false;

	const claims = decodeJWT<CustomJwtPayload>(jwtToken);
	userVar({
		_id: claims._id ?? '',
		memberType: claims.memberType ?? '',
		memberStatus: claims.memberStatus ?? '',
		memberAuthType: claims.memberAuthType ?? AUTH_CONSTANTS.DEFAULT_AUTH_TYPE,
		memberPhone: claims.memberPhone ?? '',
		memberNick: claims.memberNick ?? '',
		memberFullName: claims.memberFullName ?? '',
		memberImage:
			claims.memberImage === null || claims.memberImage === undefined
				? AUTH_CONSTANTS.DEFAULT_PROFILE_IMAGE
				: `${claims.memberImage}`,
		memberAddress: claims.memberAddress ?? '',
		memberDesc: claims.memberDesc ?? '',
		memberProperties: claims.memberProperties,
		memberRank: claims.memberRank,
		memberArticles: claims.memberArticles,
		memberPoints: claims.memberPoints,
		memberLikes: claims.memberLikes,
		memberViews: claims.memberViews,
		memberWarnings: claims.memberWarnings,
		memberBlocks: claims.memberBlocks,
	});
};

export const logOut = () => {
	deleteStorage();
	deleteUserInfo();
	// 무한 새로고침 방지를 위해 안전한 로그아웃 함수 사용
	safeLogout();
};

const deleteStorage = () => {
	localStorage.removeItem(AUTH_CONSTANTS.TOKEN_KEY);
	window.localStorage.setItem(AUTH_CONSTANTS.LOGOUT_TIME_KEY, Date.now().toString());
};

const deleteUserInfo = () => {
	userVar({
		_id: '',
		memberType: '',
		memberStatus: '',
		memberAuthType: AUTH_CONSTANTS.DEFAULT_AUTH_TYPE,
		memberPhone: '',
		memberNick: '',
		memberFullName: '',
		memberImage: '',
		memberAddress: '',
		memberDesc: '',
		memberProperties: 0,
		memberRank: 0,
		memberArticles: 0,
		memberPoints: 0,
		memberLikes: 0,
		memberViews: 0,
		memberWarnings: 0,
		memberBlocks: 0,
	});
};

// AuthProvider 유틸리티 함수들
export const isValidAuthType = (authType: string): authType is AuthProvider => {
	return Object.values(AuthProvider).includes(authType as AuthProvider);
};

export const getAuthTypeDisplayName = (authType: AuthProvider): string => {
	switch (authType) {
		case AuthProvider.EMAIL:
		case AuthProvider.PHONE:
			return '로컬';
		case AuthProvider.GOOGLE:
			return 'Google';
		case AuthProvider.FACEBOOK:
			return 'Facebook';
		case AuthProvider.KAKAO:
			return '카카오';
		case AuthProvider.GITHUB:
			return 'GitHub';
		default:
			return '알 수 없음';
	}
};

export const isSocialAuthType = (authType: AuthProvider): boolean => {
	return [
		AuthProvider.GOOGLE,
		AuthProvider.FACEBOOK,
		AuthProvider.KAKAO,
		AuthProvider.GITHUB,
	].includes(authType);
};

export const isTraditionalAuthType = (authType: AuthProvider): boolean => {
	return [AuthProvider.EMAIL, AuthProvider.PHONE].includes(authType);
};

// 소셜 로그인 함수들
export const socialLogin = async (authType: AuthProvider, token: string): Promise<void> => {
	if (!isSocialAuthType(authType)) {
		throw new Error('Invalid social auth type');
	}

	try {
		const { jwtToken } = await requestSocialJwtToken({ authType, token });

		if (jwtToken) {
			updateStorage({ jwtToken });
			updateUserInfo(jwtToken);
		}
	} catch (err) {
		console.warn('social login err', err);
		logOut();
		throw new Error('Social Login Err');
	}
};

const requestSocialJwtToken = async ({
	authType,
	token,
}: {
	authType: AuthProvider;
	token: string;
}): Promise<{ jwtToken: string }> => {
	const apolloClient = await initializeApollo();

	try {
		// TODO: 소셜 로그인 mutation 구현 필요
		const result = await apolloClient.mutate({
			mutation: LOGIN, // 임시로 기존 LOGIN 사용
			variables: { 
				input: { 
					memberNick: '', 
					memberPassword: '',
					memberAuthType: authType,
					socialToken: token 
				} 
			},
			fetchPolicy: 'network-only',
		});

		console.log('---------- social login ----------');
		const { accessToken } = result?.data?.login;

		return { jwtToken: accessToken };
	} catch (err: any) {
		console.log('request social token err', err.graphQLErrors);
		await sweetMixinErrorAlert('소셜 로그인에 실패했습니다.');
		throw new Error('social token error');
	}
};

// 이메일 인증 함수
export const emailSignUp = async (nick: string, password: string, email: string, memberType: MemberType = MemberType.USER): Promise<void> => {
	return signUp(nick, password, email, AuthProvider.EMAIL, memberType);
};

// 전화번호 인증 함수
export const phoneSignUp = async (nick: string, password: string, phone: string, memberType: MemberType = MemberType.USER): Promise<void> => {
	return signUp(nick, password, phone, AuthProvider.PHONE, memberType);
};
